## Build A Responsive Adventures Website With HTML, CSS, and JavaScript

> Improve your HTML and CSS skills by building a responsive website. After completing this lesson, you will be able to create responsive layouts using Flexbox and Grid.

#### Watch the video [here](https://youtu.be/3-t3Zmtsvb8)

![Project humbnail](/thumbnail.jpg)
